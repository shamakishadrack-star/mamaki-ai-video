import "dotenv/config";
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { fal } from "@fal-ai/client";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();

app.use(express.json({limit:"1mb"}));
app.use(express.static(__dirname));

if (process.env.FAL_KEY) fal.config({credentials:process.env.FAL_KEY});

app.post("/api/generate", async (req,res)=>{
  try{
    if(!process.env.FAL_KEY) return res.status(503).json({error:"The video engine is not connected yet."});
    const {prompt,style="Realistic",aspectRatio="9:16"}=req.body;
    if(!prompt?.trim()) return res.status(400).json({error:"Please describe your video."});
    const styleText={
      "Realistic":"photorealistic live-action, natural motion, realistic lighting",
      "Cinematic":"cinematic film look, professional camera movement, dramatic lighting",
      "Cartoon":"high-quality 3D cartoon animation, expressive characters",
      "3D Animation":"high-quality 3D animated scene, smooth camera motion",
      "AI Avatar":"professional digital presenter/avatar, natural movement"
    }[style] || "high-quality video";

    const result=await fal.subscribe("fal-ai/wan/v2.7/text-to-video",{
      input:{
        prompt:`${styleText}. ${prompt.trim()}`,
        aspect_ratio:aspectRatio,
        resolution:"720p",
        duration:"5"
      },
      logs:false
    });
    const url=result?.data?.video?.url;
    if(!url) return res.status(502).json({error:"No video was returned."});
    res.json({ok:true,videoUrl:url});
  }catch(e){
    console.error(e);
    res.status(500).json({error:"Video generation failed. Check the server logs."});
  }
});

app.get("*splat",(req,res)=>res.sendFile(path.join(__dirname,"index.html")));
const port=process.env.PORT||3000;
app.listen(port,"0.0.0.0",()=>console.log(`MAMAKI AI VIDEO running on ${port}`));
